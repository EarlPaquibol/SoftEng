def rotate_word(str, int):
    for c in str:
        letter.append(ord(c))
    pass





rotate_word('cheer', 7)
